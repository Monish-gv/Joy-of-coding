#include <stdio.h>
int main()
{
    int num=22;
    num=num<<1;
    printf("1st left shift is:%d\t",num);
    num=num<<2;
    printf("1st left shift is:%d\t",num);
    num=num<<3;
    printf("1st left shift is:%d\t",num);
    printf("\n");
    num=22;
    num=num>>1;
    printf("1st left shift is:%d\t",num);
    num=num>>2;
    printf("1st left shift is:%d\t",num);
    num=num>>3;
    printf("1st left shift is:%d\t",num);

}